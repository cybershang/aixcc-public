# cAPI Submission Artifacts

This directory contains the CRS-specific submissions received by the cAPI during
the AIxCC Semifinals Competition (ASC) event. Alongside the submission data
is the output from the cAPI evaluation steps that determine the validity of the
submission per the ASC scoring guidelines.

The contained sub-directories are organized as follows:

```
<CP Name>
└── <VD UUID>
    ├── entry.json (collection of raw cAPI logs and aggregate metadata)
    ├── <pov_blob> (optional - identified by its sha256 value)
    ├── <gp_patch> (optional - identified by its sha256 value)
    ├── output-<...>.tar.xz (optional - tarball of cAPI output from an evaluation step)
```

Each CP contains some number of sub-directories where each is identified by
the VD UUID string. The contents of the VD UUID sub-folder include the CRS' submissions
and the cAPI worker output tarballs associated with each step of the evaluation
process. Also included is a file "entry.json" that contains the raw cAPI logs
associated with the VD UUID submission and evaluation steps.

In the "entry.json" file is the field "raw_logs". This contains the raw cAPI
audit logs associated with the given submission. The individual audit log entries
in this field will call out the PoV blob sha256 filename (see the field "pov_blob_sha256"),
and the GP patch file sha256 filename (see the field "patch_sha256") if one
was submitted. The individual cAPI worker output files for various steps
carried out during the evaluation are identified by the field "filename" under
events with the type "cp_output_archived". The cAPI worker output tarballs
must be extracted to view the "stdout.log" and "stderr.log" files contained within.
